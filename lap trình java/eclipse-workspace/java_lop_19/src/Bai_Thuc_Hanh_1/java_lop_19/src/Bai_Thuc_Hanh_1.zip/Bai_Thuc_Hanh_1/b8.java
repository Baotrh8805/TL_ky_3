package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b8 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("tinh tong S=1+1/2+...+1/n");
		System.out.print("Nhap n: ");
		int n = sc.nextInt();
		double t=0;
		while(n!=0) {
			t+=(double)1/n;
			n--;
		}
		System.out.print("S= "+t);
		sc.close();
	}
}
