package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b15 {
	public static void main(String[] srgn) {
		Scanner sc = new Scanner(System.in);
		System.out.println("kiem tra so chinh phuong!");
		System.out.print("nhap so: ");
		double n=sc.nextInt();
		if( Math.sqrt(n) == (int)Math.sqrt(n) ) {
			System.out.print((int)n+" la so chinh phuong vi "+ (int)n + "="+(int)Math.sqrt(n)+"^2");
		}else {
			System.out.print((int)n+" khong la so chinh phuong");
		}
		sc.close();
	}
}
	
