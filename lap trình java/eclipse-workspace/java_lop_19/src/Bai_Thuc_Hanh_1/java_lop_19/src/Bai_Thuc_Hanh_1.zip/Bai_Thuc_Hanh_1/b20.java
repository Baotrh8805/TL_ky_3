package Bai_Thuc_Hanh_1;
import java.util.*;
public class b20 {
	public static void main(String[] srgn) {
		Scanner sc = new Scanner(System.in);
		System.out.println("kiem ra so Fibonaci !!");
		sc.close();
	}
}
