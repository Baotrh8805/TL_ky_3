package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b16 {
	public static void main(String[] srgn) {
		Scanner sc = new Scanner(System.in);
		System.out.println("kiem tra so doi xung!");
		System.out.print("nhap so: ");
		int n=sc.nextInt();
		int k=n;
		int x=0;
		while(n>0) {
			x=x*10 + (n%10);
			n/=10;
		}
		if(x==k) {
			System.out.print(k+" la so doi xung");
			
		}else {
			System.out.print(k+" khong la so doi xung");

		}
		sc.close();
	}
}
