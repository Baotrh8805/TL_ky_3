package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b10 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("tinh tong S=1+1/3!+...+1/n");
		System.out.print("Nhap n: ");
		int n = sc.nextInt();
		double t=1;
		double s=1;
		int i=1;
		while(i<=2*n-1) {
			t=t*1/(i+1)/(i+2);
			s+=t;
			i+=2;
		}
		System.out.print("S= "+s);
		sc.close();
	}
}
