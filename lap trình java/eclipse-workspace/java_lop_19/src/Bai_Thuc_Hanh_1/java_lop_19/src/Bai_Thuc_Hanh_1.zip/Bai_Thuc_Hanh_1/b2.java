package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a, b;
		System.out.println("giai phuong trinh ax + b = 0");
		
		while (true){
			System.out.print("nhap a(a!=0): ");
			a = sc.nextInt();
			if(a==0) {
				System.out.println("nhap lai a!!");
			}else {
				break;
			}
		}

		System.out.print("nhap b: ");
		b = sc.nextInt();
		System.out.print("gia tri x = " + ((double)-b / a));
		sc.close();
	}
}
