package Bai_Thuc_Hanh_1;

import java.util.Scanner;

public class b12 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("tinh tong va tich cua ca chu so trong 1 so!");
		System.out.print("Nhap so: ");
		int n = sc.nextInt();
		int t =1;
		int s=0;
		int i;
		while(n>0)  {
			i=n%10;
			s+=i;
			t*=i;
			n/=10;
		}
		
		System.out.print("S= " + s);
		System.out.print("P= " + t);

		sc.close();
	}
}
