using System;

namespace QuanLyQuanNet.Models
{
    public class SuDungMay
    {
        public int MaSuDung { get; set; }

        public int MaNguoiDung { get; set; }
        public NguoiDung NguoiDung { get; set; }

        public int MaMay { get; set; }
        public MayTinh MayTinh { get; set; }

        public DateTime ThoiGianBatDau { get; set; }
        public DateTime? ThoiGianKetThuc { get; set; }

        public int TongPhut { get; set; }
        public decimal TongTien { get; set; }
    }
}
