using System;

namespace QuanLyQuanNet.Models
{
    public class LichSuNapTien
    {
        public int MaLichSu { get; set; }

        public int MaNguoiDung { get; set; }
        public NguoiDung NguoiDung { get; set; }

        public decimal SoTien { get; set; }
        public DateTime ThoiGian { get; set; }
    }
}
