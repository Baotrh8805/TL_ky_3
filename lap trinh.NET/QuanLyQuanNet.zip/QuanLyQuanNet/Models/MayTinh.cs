namespace QuanLyQuanNet.Models
{
    public class MayTinh
    {
        public int MaMay { get; set; }
        public string TenMay { get; set; }
        public string TrangThai { get; set; } // trong, dang_su_dung, hong
        public decimal DonGiaGio { get; set; }

        public ICollection<SuDungMay> SuDungMays { get; set; }
    }
}
