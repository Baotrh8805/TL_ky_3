using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QuanLyQuanNet.Models
{
    [Table("nguoi_dung")]
    public class NguoiDung
    {
        [Key]
        [Column("ma_nguoi_dung")]
        public string MaNguoiDung { get; set; }

        [Column("ho_ten")]
        public string HoTen { get; set; }

        [Column("ten_dang_nhap")]
        public string TenDangNhap { get; set; }

        [Column("mat_khau")]
        public string MatKhau { get; set; }

        [Column("so_dien_thoai")]
        public string SoDienThoai { get; set; }

        [Column("so_du")]
        public decimal? SoDu { get; set; }

        [Column("vai_tro")]
        public string VaiTro { get; set; } = "user"; // Giá trị mặc định là user
    }
}
