using Microsoft.EntityFrameworkCore;

namespace QuanLyQuanNet.Models
{
    public class QuanLyNetContext : DbContext
    {
        public QuanLyNetContext(DbContextOptions<QuanLyNetContext> options) : base(options) { }

        public DbSet<MayTinh> MayTinhs { get; set; }
        public DbSet<NguoiDung> NguoiDungs { get; set; }
        public DbSet<SuDungMay> SuDungMays { get; set; }
        public DbSet<LichSuNapTien> LichSuNapTiens { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MayTinh>().ToTable("may_tinh");
            modelBuilder.Entity<NguoiDung>().ToTable("nguoi_dung");
            modelBuilder.Entity<SuDungMay>().ToTable("su_dung_may");
            modelBuilder.Entity<LichSuNapTien>().ToTable("lich_su_nap_tien");
        }
    }
}
