using Microsoft.EntityFrameworkCore;
using QuanLyQuanNet.Models;

var builder = WebApplication.CreateBuilder(args);

// ✅ Cấu hình DbContext
builder.Services.AddDbContext<QuanLyNetContext>(options =>
    options.UseMySql(
        builder.Configuration.GetConnectionString("QuanLyNetConnection"),
        ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("QuanLyNetConnection")) // ✅ Phải trùng tên!
    ));

// ✅ Cấu hình Session
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // session hết hạn sau 30 phút không hoạt động
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// ✅ Cấu hình service (DI)
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddScoped<TaiKhoanService>(); // <-- Thêm dòng này


var app = builder.Build();

app.UseStaticFiles();

// ✅ Kích hoạt session
app.UseSession();

app.UseRouting();
app.UseAuthorization();

// ✅ Map route chuẩn MVC
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
