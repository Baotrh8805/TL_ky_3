using Microsoft.AspNetCore.Mvc;

namespace QuanLyQuanNet.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(); // Tìm Views/Home/Index.cshtml
        }
    }
}
