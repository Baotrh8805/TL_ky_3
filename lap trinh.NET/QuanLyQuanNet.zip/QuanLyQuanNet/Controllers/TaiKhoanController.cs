using Microsoft.AspNetCore.Mvc;
using QuanLyQuanNet.Models;
using QuanLyQuanNet.Services;

namespace QuanLyQuanNet.Controllers
{
    public class TaiKhoanController : Controller
    {
        private readonly TaiKhoanService _service;

        public TaiKhoanController(TaiKhoanService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult DangKy() => View();

        [HttpPost]
        public IActionResult DangKy(NguoiDung nguoi)
        {
            if (_service.DangKy(nguoi))
            {
                TempData["ThongBao"] = "Đăng ký thành công!";
                return RedirectToAction("Index", "Home");
            }

            ModelState.AddModelError("", "Tên đăng nhập đã tồn tại!");
            return View(nguoi);
        }
    }
}
