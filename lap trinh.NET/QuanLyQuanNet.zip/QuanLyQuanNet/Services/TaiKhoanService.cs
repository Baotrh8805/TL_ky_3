using QuanLyQuanNet.Models;

public class TaiKhoanService
{
    private readonly QuanLyNetContext _context;

    public TaiKhoanService(QuanLyNetContext context)
    {
        _context = context;
    }

    public bool DangKy(NguoiDung nguoi)
    {
        if (_context.NguoiDungs.Any(x => x.TenDangNhap == nguoi.TenDangNhap))
            return false;

        nguoi.MaNguoiDung = Guid.NewGuid().ToString();
        _context.NguoiDungs.Add(nguoi);
        _context.SaveChanges();
        return true;
    }

    public NguoiDung DangNhap(string tenDangNhap, string matKhau)
    {
        return _context.NguoiDungs
            .FirstOrDefault(x => x.TenDangNhap == tenDangNhap && x.MatKhau == matKhau);
    }
}
